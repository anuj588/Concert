export default function Aboutus() {

  return (
    <div className="mt-3 mx-auto p-4 text-center" style={{width:"96%",background:"white"}}>
      <div className="fw-bold fs-2" id="aboutus">About Concert Ticket Booking</div>
      <p className='mx-auto' style={{width:"70%"}}>  Welcome to Our Website, your one-stop for all the latest shows information and ticket sales! 
       Our platform keeps fans up-to-date on the latest shows in their area and to purchase tickets online.
       If you have any questions or feedback, please don't hesitate to contact us. We would love to hear from you!
      </p>

    </div>
  );
}
